public class DateAndTimeDriver {
    public static void main(String[] args) {
    // Creating a new instance of DateAndTimeTester 'dtTester'
    DateAndTimeTester dtTester = new DateAndTimeTester();
    
    dtTester.run();
    }
    }
    